function loadTxt() {
  document.getElementById("txtLang").innerHTML = "\u0412\u0441\u0442\u0430\u0432\u044c\u0442\u0435 \u0442\u0435\u043a\u0441\u0442 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u044f \u043a\u043b\u0430\u0432\u0438\u0430\u0442\u0443\u0440\u0443 (CTRL-V) ";
  document.getElementById("btnCancel").value = "\u041e\u0442\u043c\u0435\u043d\u0430";
  document.getElementById("btnOk").value = " ok "
}
function writeTitle() {
  document.write("<title>\u0412\u0441\u0442\u0430\u0432\u043a\u0430 \u0442\u0435\u043a\u0441\u0442\u0430</title>")
}
;