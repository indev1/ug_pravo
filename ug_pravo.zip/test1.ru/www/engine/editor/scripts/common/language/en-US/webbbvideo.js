function loadTxt() {
  document.getElementById("lblUrl").innerHTML = "\u0421\u0441\u044b\u043b\u043a\u0430 \u043d\u0430 \u0432\u0438\u0434\u0435\u043e:";
  document.getElementById("lblTitle").innerHTML = "\u0421\u0441\u044b\u043b\u043a\u0430 \u043d\u0430 \u0438\u0437\u043e\u0431\u0440\u0430\u0436\u0435\u043d\u0438\u0435 (\u043e\u043f\u0446\u0438\u043e\u043d\u0430\u043b\u044c\u043d\u043e):";
  document.getElementById("btnCancel").value = "\u041e\u0442\u043c\u0435\u043d\u0430";
  document.getElementById("btnLink").value = "\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044c"
}
function writeTitle() {
  document.write("<title>" + "\u0412\u0441\u0442\u0430\u0432\u043a\u0430 \u0441\u0441\u044b\u043b\u043a\u0438 \u043d\u0430 \u0432\u0438\u0434\u0435\u043e" + "</title>")
}
;