<?PHP

define ("DBHOST", "localhost"); 

define ("DBNAME", "ug_pravo");

define ("DBUSER", "truhman");

define ("DBPASS", "qwerty");  

define ("PREFIX", "po61"); 

define ("USERPREFIX", "po61");

define ("COLLATE", "cp1251"); 

define('SECURE_AUTH_KEY', '[8b`jsy:Vh%/aE8#lBmXF`iRH/;1b7@(dTl[k&F`n?*AJ7: 0P@]2+N+[A#VT4dI');

$db = new db;
 
?>